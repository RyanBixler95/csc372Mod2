package csc372mod2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GUI {
	public JFrame frame;
	public JPanel panel;
	public JButton depositButton, withdrawButton, balanceButton;
	public JTextField amountField;
	public JLabel balanceLabel;
	public UserBankAccount userAccount;
	
	public GUI(UserBankAccount userAccount)	{
		this.userAccount = userAccount;
		
		frame = new JFrame("Bank of Ryan: User Balance Portal");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(new GridLayout(4, 2));
		
		amountField = new JTextField();
		depositButton = new JButton("Deposit");
		withdrawButton = new JButton("Withdraw");
		balanceButton = new JButton("Show Balance");
		balanceLabel = new JLabel("Balance: $0.00");
		
		depositButton.addActionListener(new ActionListener()	{
			@Override
			public void actionPerformed(ActionEvent e)	{
				try	{
					double amount = Double.parseDouble(amountField.getText());
					userAccount.deposit(amount);
					amountField.setText("");
				} catch(NumberFormatException ex)	{
					JOptionPane.showMessageDialog(frame, "Please enter a valid number.");
				}
			}
		});
		
		withdrawButton.addActionListener(new ActionListener()	{
			@Override
			public void actionPerformed(ActionEvent e)	{
				try	{
					double amount = Double.parseDouble(amountField.getText());
					userAccount.withdraw(amount);
					amountField.setText("");
				} catch(NumberFormatException ex)	{
					JOptionPane.showMessageDialog(frame, "Please enter a valid number.");
				}
			}
		});
		
		balanceButton.addActionListener(new ActionListener()	{
			@Override
			public void actionPerformed(ActionEvent e)	{
				balanceLabel.setText("Balance: $" + userAccount.displayBalance());
			}
		});
		
		panel.add(new JLabel("Amount:"));
		panel.add(amountField);
		panel.add(depositButton);
		panel.add(withdrawButton);
		panel.add(balanceButton);
		panel.add(balanceLabel);
		
		frame.add(panel);
		frame.pack();
		frame.setVisible(true);
	}
	
	public static void main(String[] args)	{
		UserBankAccount userAccount = new UserBankAccount(0);
		new GUI(userAccount);
	}
}
