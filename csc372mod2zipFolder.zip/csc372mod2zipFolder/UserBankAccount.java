package csc372mod2;

public class UserBankAccount {
	private double balance;
	
	public UserBankAccount(double initialBalance)	{
		this.balance = initialBalance;
	}
	
	public double getBalance()	{
		return balance;
	}
	
	public void deposit(double amount)	{
		if(amount > 0)	{
			balance += amount;
		}
	}
	
	public void withdraw(double amount)	{
		if (amount > 0 && amount <= balance)	{
			balance -= amount;
		}
	}
	
	public String displayBalance()	{
		return String.format("%.2f", balance);
	}
}
